PHP code to connect to MySQL database

<?php 

$con=mysqli_connect("db154.pair.com","1032364_2","!MoneySZN004","mikemitch4_schoolAdmin");

// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
mysqli_close($con);

?>
