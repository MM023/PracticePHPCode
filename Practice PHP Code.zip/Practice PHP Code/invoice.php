﻿<html>
<body>


<?php 

$item1 = $_GET["item1"]; 
$price1 = $_GET["price1"]; 
$quantity1 = $_GET["quantity1"]; 
$total1 = $price1 * $quantity1; 

$item2 = $_GET["item2"]; 
$price2 = $_GET["price2"]; 
$quantity2 = $_GET["quantity2"]; 
$total2 = $price2 * $quantity2;  

$item3 = $_GET["item3"]; 
$price3 = $_GET["price3"]; 
$quantity3 = $_GET["quantity3"]; 
$total3 = $price2 * $quantity3;  

$item4 = $_GET["item4"]; 
$price4 = $_GET["price4"]; 
$quantity4 = $_GET["quantity4"]; 
$total4 = $price4 * $quantity4;   

$salestaxrate = $_GET["salestax"]; 

$subtotal = $total1 + $total2 + $total3 + $total4;  

$grandtotal = $subtotal + (0.01 * $salestaxrate * $subtotal); 



?> 

<table border="1">
<tr>

 <th>Item Name</th>
  
 <th>Price</th>
    
 <th>Quantity</th>
   
 <th>Total</th>
 
</tr> 

<tr>
	<td> 
	<? echo $item1 ?>

	</td>

	<td> 
	<? echo "$". $price1 ?>

	</td> 

	<td> 
	<? echo $quantity1 ?>

	</td> 

	<td> 
	<? echo "$". $total1 ?>

	</td>

</tr>

<tr>
	<td> 
	<? echo $item2 ?>

	</td>

	<td> 
	<? echo "$". $price2 ?>

	</td> 

	<td> 
	<? echo $quantity2 ?>

	</td> 

	<td> 
	<? echo "$". $total2 ?>

	</td>

</tr> 

<tr>
	<td> 
	<? echo $item3 ?>

	</td>

	<td> 
	<? echo "$". $price3 ?>

	</td> 

	<td> 
	<? echo $quantity3 ?>

	</td> 

	<td> 
	<? echo "$". $total3 ?>

	</td>

</tr> 

<tr>
	<td> 
	<? echo $item4 ?>

	</td>

	<td> 
	<? echo "$". $price4 ?>

	</td> 

	<td> 
	<? echo $quantity4 ?>

	</td> 

	<td> 
	<? echo "$". $total4 ?>

	</td>

</tr> 

<tr>
	<td colspan="4"> 
    <? echo "The total of all the items without tax is $". $subtotal ?>

	</td>
</tr> 

<tr>
	<td colspan="4"> 
    <? echo "The grandtotal of all the items with tax is $". $grandtotal ?>

	</td>
</tr> 

</table>

</body>
</html> 