<!doctype html>
<html lang="en" dir="ltr">
<head>
   <title>PHP Multiplication Table</title>
   <meta charset="utf-8" />
   <style>
      <!--
         body {font:normal 15px arial,sans-serif;}
         table {background-color:#000;border:3px solid #000;}
         th,td {width:30px;height:30px; font-weight: normal;}
         th {background-color:#ffffff;color:#000;}
         td {background-color:#ffffff;text-align:center;}
      -->
   </style>
</head>
<body>
   <h1>Multiplication Table</h1> 

<table>
    <thead>
        <tr>
            <th>&nbsp;</th>
            <?php for($i=1; $i<=12; $i++) { ?>
                <th><?php echo $i; ?></th>
            <?php } ?>
        </tr>
    </thead>
    <tbody>
        <?php for($i=1; $i<=12; $i++) { ?>
        <tr>
            <td><?php echo $i; ?></td>
            <?php for($j=1; $j<=12; $j++) { ?>
                <td><?php echo $i*$j; ?></td>
            <?php } ?>
        </tr>
        <?php } ?>
    </tbody>
</table>

</body>
</html>

