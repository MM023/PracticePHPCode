PHP code to connect to MySQL database

<?php 

$con = mysqli_connect('db154.pair.com', '1032364', 'odutesting', 'mikemitch4_students');


?> 