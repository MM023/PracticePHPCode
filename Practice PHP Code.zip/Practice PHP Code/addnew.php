PHP code to add a new student into MySQL database.

<?php  

session_start(); 
require 'connect2.php';  

$epr=''; 
$msg=''; 

if(isset($_GET['epr'])) 
    $epr=$_GET['epr']; 

    if($epr=='save')
        { 

            $username = $_POST['username']; 
            $password = $_POST['password'];  
            $firstname = $_POST['fname'];  
            $lastname = $_POST['lname']; 

            $a_sql=mysqli_query($con, "INSERT INTO students VALUES('$username','$password','$firstname', '$lastname')"); 

            if($a_sql)
                $msg='You were successful adding a new record!'; 
            else 
                $msg= 'Error ';

        } 

?>

<h2 align="center">Add New Student</h2> 

<form method="post" action="welcome.php?epr=save">  
    <table align="center">
    <tr> 
        <td>Username:</td> 
        <td><input type="text" name="username"></td> 
        </tr>
    </tr> 
    <tr> 
        <td>Password:</td> 
        <td><input type="text" name="password"></td> 
        </tr>
    </tr> 
     <tr> 
        <td>First Name:</td> 
        <td><input type="text" name="fname"></td> 
        </tr>
    </tr>  
     <tr> 
        <td>Last Name</td> 
        <td><input type="text" name="lname"></td> 
        </tr>
    </tr> 
    <tr> 
        <td></td> 
        <td><input type= "submit" name="submit"></td> 
    </tr>
    
</table> 
</form> 

<?php 

echo $msg;

?> 