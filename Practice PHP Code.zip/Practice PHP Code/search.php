<?php 
session_start(); 
require 'connect2.php';   

?>


<html> 
<body> 

<h3>Search student Records</h3>

You may search either by first or last name.

<br>

<form action="" method="GET">
		<input type="text" name="query" />
		<input type="submit" value="Search" name="searchform" />
</form>


<?php



if(isset($_GET['searchform'])) { 
$query = $_GET['query'];

$result = mysqli_query($con, "SELECT username, password, fname, lname FROM students
			WHERE (`fname` LIKE '%".$query."%') OR (`lname` LIKE '%".$query."%')") or die(mysql_error()); 
 

if ($result->num_rows > 0) { 
while($row = $result->fetch_assoc()) { 

 echo "<tr>"; 

echo "<table border='1'>
<tr>
<th>Username</th>
<th>Password</th> 
<th>Firstname</th>
<th>Lastname</th>  


</tr>";

        echo "<td>{$row['username']}</td>";
        echo "<td>{$row['password']}</td>"; 
        echo "<td>{$row['fname']}</td>";
        echo "<td>{$row['lname']}</td>"; 
    } 
       echo "</table>";
} else {
     echo "0 results";
}

}

?>

</body>
</html> 