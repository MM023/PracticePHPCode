<center>

<?php 
session_start(); 
echo 'Login successful! Welcome '.$_SESSION['username'];  
require 'connect2.php';  

$epr=''; 
$msg=''; 

if(isset($_GET['epr'])) 
    $epr=$_GET['epr']; 
        

        //++++++++++++++++++++++++++++++++++++++++++++saverecord+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        if($epr=='save')
        { 
            $username = $_POST['username']; 
            $password = $_POST['password'];  
            $firstname = $_POST['fname'];  
            $lastname = $_POST['lname']; 

            $a_sql=mysqli_query($con, "INSERT INTO students VALUES('$username','$password','$firstname', '$lastname')"); 
            if($a_sql)
                $msg='You successfully added a new record!'; 
            else 
                $msg= 'Error! ';
        }
        //++++++++++++++++++++++++++++++++++++++++++++saverecord+++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        //++++++++++++++++++++++++++++++++++++++++++++delete record+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        if($epr=='delete'){  
            $username = $_GET['username']; 
            $delete=mysqli_query($con, "DELETE FROM students WHERE username='$username'"); 
            if($delete) 
                header("location: welcome.php");
            else 
                $msg= 'Error: '.mysql_error();
            } 
        //++++++++++++++++++++++++++++++++++++++++++++delete record+++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
       
?> 
</center>



<hr>
<br>
<br> 

<html> 
    <head> 
    </head> 

    <body>


<center> 

<a href ="addnew.php">Add a New Record</a>
<a href ="search.php">Search the Database</a>


<?php 


$result = mysqli_query($con, "SELECT username, password, fname, lname FROM students");

echo "<table border='1'>
<tr>
<th>Username</th>
<th>Password</th> 
<th>Firstname</th>
<th>Lastname</th>  
<th>Delete</th> 

</tr>";


 if ($result->num_rows > 0) {
     
     // output data of each row
     while($row = $result->fetch_assoc()) { 
        echo "<tr>";
        echo "<td>{$row['username']}</td>";
        echo "<td>{$row['password']}</td>"; 
        echo "<td>{$row['fname']}</td>";
        echo "<td>{$row['lname']}</td>"; 
        echo "<td> <a href ='welcome.php?epr=delete&username=".$row['username']."'>DELETE</a> </td>";
        
        echo "</tr>";
        
     } 
       echo "</table>";
} else {
     echo "0 results";
}

echo $msg;

?>   



</center>  
</body>
</html>